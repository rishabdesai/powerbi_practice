
-- Stored Procedure to Summarize Executive KPIs
CREATE PROCEDURE usp_ExecutiveSummary AS
BEGIN
    SELECT 
        Region,
        SUM(TotalRevenue) AS Revenue,
        SUM(TargetRevenue) AS Target,
        SUM(ProjectDelays) AS DelayedProjects,
        SUM(ActiveDeals) AS ActivePipeline
    FROM SalesSummary
    GROUP BY Region
END;
